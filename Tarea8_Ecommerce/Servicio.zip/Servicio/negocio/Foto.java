/*
  Carlos Pineda Guerrero, marzo 2022.
*/

package negocio;

public class Foto
{
	public int id_foto;
	public byte[] foto;
}
